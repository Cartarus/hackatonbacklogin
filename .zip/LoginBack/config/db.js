const { process } = require("grunt");
const mongoose = require("mongoose");

const connectDB = async () =>{
    try {
        const connect = await mongoose.connect('mongodb+srv://JosePajaro:123@cluster0.e6wykx9.mongodb.net/Trabajanding?retryWrites=true&w=majority');
        console.log(
            "Database Connected: ",
            connect.connection.host, 
            connect.connection.name
        );
    } catch (error) {
        console.log(error);
    }
}

module.exports = connectDB;